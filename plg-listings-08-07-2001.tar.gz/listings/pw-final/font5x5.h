char *Font5x5[] = {

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"     ",

"  X  "\
"  X  "\
"  X  "\
"     "\
"  X  ",

" X X "\
" X X "\
"     "\
"     "\
"     ",

" X X "\
"XXXXX"\
" X X "\
"XXXXX"\
" X X ",

" XXXX"\
"X X  "\
" XXX "\
"  X X"\
"XXXX ",

"XX  X"\
"XX X "\
"  X  "\
" X XX"\
"X  XX",

" XX  "\
"X  X "\
" XX  "\
"X X  "\
"XX X ",

"  X  "\
"  X  "\
"     "\
"     "\
"     ",

"  X  "\
" X   "\
" X   "\
" X   "\
"  X  ",

"  X  "\
"   X "\
"   X "\
"   X "\
"  X  ",

"X X X"\
" XXX "\
"XXXXX"\
" XXX "\
"X X X",

"  X  "\
"  X  "\
"XXXXX"\
"  X  "\
"  X  ",

"     "\
"     "\
"     "\
"   X "\
"  X  ",

"     "\
"     "\
"XXXXX"\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"  X  ",

"    X"\
"   X "\
"  X  "\
" X   "\
"X    ",

" XXX "\
"X  Xx"\
"X X X"\
"XX  X"\
" XXX ",

"  X  "\
" XX  "\
"  X  "\
"  X  "\
" XXX ",

" XXX "\
"    X"\
"   X "\
"  x  "\
" XXXX",

" XXX "\
"    X"\
"  XX "\
"    X"\
" XXX ",

" X  X"\
" X  X"\
" XXXX"\
"    X"\
"    X",

" XXXX"\
" X   "\
" XXX "\
"    X"\
" XXX ",

"  XXX"\
" X   "\
" XXX "\
" X  X"\
"  XX ",

" XXXX"\
"    X"\
"   X "\
"  X  "\
"  X  ",

"  XX "\
" X  X"\
"  XX "\
" X  X"\
"  XX ",

"  XX "\
" X  X"\
"  XXX"\
"    X"\
"   X ",

"     "\
"  X  "\
"     "\
"  X  "\
"     ",

"     "\
"  X  "\
"     "\
"  X  "\
" X   ",

"   X "\
"  X  "\
" X   "\
"  X  "\
"   X ",

"     "\
"XXXXX"\
"     "\
"XXXXX"\
"     ",

" X   "\
"  X  "\
"   X "\
"  X  "\
" X   ",

" XXX "\
"   X "\
"  X  "\
"     "\
"  X  ",

" XXX "\
"X XXX"\
"X XXX"\
"X    "\
" XXX ",

" XXX "\
"X   X"\
"XXXXX"\
"X   X"\
"X   X",

"XXXX "\
"X   X"\
"XXXX "\
"X   X"\
"XXXX ",

" XXXX"\
"X    "\
"X    "\
"X    "\
" XXXX",

"XXXX "\
"X   X"\
"X   X"\
"X   X"\
"XXXX ",

"XXXXX"\
"X    "\
"XXXX "\
"X    "\
"XXXXX",

"XXXXX"\
"X    "\
"XXXX "\
"X    "\
"X    ",

" XXXX"\
"X    "\
"X  XX"\
"X   X"\
" XXXX",

"X   X"\
"X   X"\
"XXXXX"\
"X   X"\
"X   X",

" XXX "\
"  X  "\
"  X  "\
"  X  "\
" XXX ",

"  XXX"\
"   X "\
"   X "\
"X  X "\
" XX  ",

"X  X "\
"X X  "\
"XX   "\
"X X  "\
"X  X ",

"X    "\
"X    "\
"X    "\
"X    "\
"XXXX ",

"X   X"\
"XX XX"\
"X X X"\
"X   X"\
"X   X",

"X   X"\
"XX  X"\
"X X X"\
"X  XX"\
"X   X",

" XXX "\
"X   X"\
"X   X"\
"X   X"\
" XXX ",

"XXXX "\
"X   X"\
"XXXX "\
"X    "\
"X    ",

" XXX "\
"X   X"\
"X   X"\
"X  XX"\
" XXXX",

"XXXX "\
"X   X"\
"XXXX "\
"X X  "\
"X  X ",

" XXXX"\
"X    "\
" XXX "\
"    X"\
"XXXX ",

"XXXXX"\
"  X  "\
"  X  "\
"  X  "\
"  X  ",

"X   X"\
"X   X"\
"X   X"\
"X   X"\
" XXX ",

"X   X"\
"X   X"\
"X   X"\
" X X "\
"  X  ",

"X   X"\
"X   X"\
"X X X"\
"X X X"\
" X X ",

"X   X"\
" X X "\
"  X  "\
" X X "\
"X   X",

"X   X"\
"X   X"\
" XXX "\
"  X  "\
"  X  ",

"XXXXX"\
"   X "\
"  X  "\
" X   "\
"XXXXX",

" XXX "\
" X   "\
" X   "\
" X   "\
" XXX ",

"X    "\
" X   "\
"  X  "\
"   X "\
"    X",

" XXX "\
"   X "\
"   X "\
"   X "\
" XXX ",

"  X  "\
" X X "\
"     "\
"     "\
"     ",

"     "\
"     "\
"     "\
"     "\
"XXXXX",

"  X  "\
"   X "\
"     "\
"     "\
"     ",


" XXX "\
"X   X"\
"XXXXX"\
"X   X"\
"X   X",

"XXXX "\
"X   X"\
"XXXX "\
"X   X"\
"XXXX ",

" XXXX"\
"X    "\
"X    "\
"X    "\
" XXXX",

"XXXX "\
"X   X"\
"X   X"\
"X   X"\
"XXXX ",

"XXXXX"\
"X    "\
"XXXX "\
"X    "\
"XXXXX",

"XXXXX"\
"X    "\
"XXXX "\
"X    "\
"X    ",

" XXXX"\
"X    "\
"X  XX"\
"X   X"\
" XXXX",

"X   X"\
"X   X"\
"XXXXX"\
"X   X"\
"X   X",

" XXX "\
"  X  "\
"  X  "\
"  X  "\
" XXX ",

"  XXX"\
"   X "\
"   X "\
"X  X "\
" XX  ",

"X  X "\
"X X  "\
"XX   "\
"X X  "\
"X  X ",

"X    "\
"X    "\
"X    "\
"X    "\
"XXXX ",

"X   X"\
"XX XX"\
"X X X"\
"X   X"\
"X   X",

"X   X"\
"XX  X"\
"X X X"\
"X  XX"\
"X   X",

" XXX "\
"X   X"\
"X   X"\
"X   X"\
" XXX ",

"XXXX "\
"X   X"\
"XXXX "\
"X    "\
"X    ",

" XXX "\
"X   X"\
"X   X"\
"X  XX"\
" XXXX",

"XXXX "\
"X   X"\
"XXXX "\
"X X  "\
"X  X ",

" XXXX"\
"X    "\
" XXX "\
"    X"\
"XXXX ",

"XXXXX"\
"  X  "\
"  X  "\
"  X  "\
"  X  ",

"X   X"\
"X   X"\
"X   X"\
"X   X"\
" XXX ",

"X   X"\
"X   X"\
"X   X"\
" X X "\
"  X  ",

"X   X"\
"X   X"\
"X X X"\
"X X X"\
" X X ",

"X   X"\
" X X "\
"  X  "\
" X X "\
"X   X",

"X   X"\
"X   X"\
" XXX "\
"  X  "\
"  X  ",

"XXXXX"\
"   X "\
"  X  "\
" X   "\
"XXXXX",

"  XX "\
"  X  "\
" X   "\
"  X  "\
"  XX ",

"  X  "\
"  X  "\
"  X  "\
"  X  "\
"  X  ",

" XX  "\
"  X  "\
"   X "\
"  X  "\
" XX  ",

"  X X"\
" X X "\
"     "\
"     "\
"     ",

NULL
};
